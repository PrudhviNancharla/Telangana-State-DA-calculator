// Telangana Government 2 DAs Difference & Arrears Calculator Application Script
// RPS 2020 — 1st DA (Jan 2024: 37.31%) & 2nd DA (Jul 2024: 40.04% | Total Diff: +6.37%)
// Baseline Drawn DA: 33.67% (July 2023 — G.O.Ms.02)
// Arrears Period: Jan-2024 to Sep-2026 (33 Months)
// Formulated by Nancharla Prudhvi, Senior Accountant, District Treasury, Khammam

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements - Input Form
  const basicpay = document.getElementById('basicpay');
  const basicSearch = document.getElementById('basicSearch');
  const customPayCheck = document.getElementById('customPayCheck');
  const customPayWrapper = document.getElementById('customPayWrapper');
  const customPayInput = document.getElementById('customPayInput');
  const activeBasicDisplay = document.getElementById('activeBasicDisplay');

  const incmonth = document.getElementById('incmonth');
  const aas = document.getElementById('aas');
  const aasMonthDiv = document.getElementById('aas-month-div');
  const aasmonth = document.getElementById('aasmonth');
  const aasDayDiv = document.getElementById('aas-day-div');
  const aasday = document.getElementById('aasday');
  const cpsorgpf = document.getElementById('cpsorgpf');

  const btnCalculate = document.getElementById('btnCalculate');
  const btnPrint = document.getElementById('btnPrint');
  const btnShare = document.getElementById('btnShare');
  const btnReset = document.getElementById('btnReset');

  // Summary Card DOM Elements
  const cardTotalArrears = document.getElementById('cardTotalArrears');
  const cardCpsWrapper = document.getElementById('cardCpsWrapper');
  const cardCpsLabel = document.getElementById('cardCpsLabel');
  const cardCpsVal = document.getElementById('cardCpsVal');
  const cardCashLabel = document.getElementById('cardCashLabel');
  const cardCashVal = document.getElementById('cardCashVal');
  const cardInstallSplit = document.getElementById('cardInstallSplit');
  const cardSlWrapper = document.getElementById('cardSlWrapper');
  const cardSlTotal = document.getElementById('cardSlTotal');
  const cardSlChips = document.getElementById('cardSlChips');

  // Top October 2026 Highlight Card next to Author Photo
  const topOctTotal = document.getElementById('topOctTotal');
  const topOctCash = document.getElementById('topOctCash');
  const topOctCps = document.getElementById('topOctCps');
  const topOctCpsChip = document.getElementById('topOctCpsChip');

  // October Month Card
  const octBadgeCash = document.getElementById('octBadgeCash');
  const octBigCash = document.getElementById('octBigCash');
  const octCpsPill = document.getElementById('octCpsPill');
  const octCpsVal = document.getElementById('octCpsVal');
  const octDa1Cash = document.getElementById('octDa1Cash');
  const octDa1Cps = document.getElementById('octDa1Cps');
  const octDa2Cash = document.getElementById('octDa2Cash');
  const octDa2Cps = document.getElementById('octDa2Cps');

  // Tables
  const da1TableBody = document.getElementById('da1TableBody');
  const da2TableBody = document.getElementById('da2TableBody');
  const gtBasic = document.getElementById('gtBasic');
  const gtEligible = document.getElementById('gtEligible');
  const gtDrawn = document.getElementById('gtDrawn');
  const gtDiff = document.getElementById('gtDiff');
  const gtCps = document.getElementById('gtCps');
  const gtCash = document.getElementById('gtCash');
  const gtSurrenderRow = document.getElementById('gtSurrenderRow');

  const installmentTableBody = document.getElementById('installmentTableBody');
  const installmentMobileContainer = document.getElementById('installmentMobileContainer');

  // Accordion
  const tsTableToggle = document.getElementById('tsTableToggle');
  const tsTableContent = document.getElementById('tsTableContent');
  const tsTableArrow = document.getElementById('tsTableArrow');
  const tsCumulativeTableBody = document.getElementById('tsCumulativeTableBody');

  // Year-by-Year Surrender Leave Elements Map (2024, 2025, 2026)
  const surrenderYears = [
    {
      year: 2024,
      item: document.getElementById('sl-item-2024'),
      slSelect: document.getElementById('sl2024'),
      monthDiv: document.getElementById('sldiv2024'),
      monthSelect: document.getElementById('slmonth2024'),
      chip: document.getElementById('chip2024')
    },
    {
      year: 2025,
      item: document.getElementById('sl-item-2025'),
      slSelect: document.getElementById('sl2025'),
      monthDiv: document.getElementById('sldiv2025'),
      monthSelect: document.getElementById('slmonth2025'),
      chip: document.getElementById('chip2025')
    },
    {
      year: 2026,
      item: document.getElementById('sl-item-2026'),
      slSelect: document.getElementById('sl2026'),
      monthDiv: document.getElementById('sldiv2026'),
      monthSelect: document.getElementById('slmonth2026'),
      chip: document.getElementById('chip2026')
    }
  ];

  // --- 1. Populate Dropdowns ---
  function populateDropdowns() {
    // Populate Basic Pay Select with RPS-2020 stages (No default pre-selected)
    basicpay.innerHTML = '<option value="" selected>-- SELECT BASIC PAY --</option>';
    RPS_2020_STAGES.forEach(st => {
      const opt = document.createElement('option');
      opt.value = st;
      opt.textContent = `₹${formatINR(st)}`;
      basicpay.appendChild(opt);
    });

    // Populate AAS Month Select (Jan 2024 to Sep 2026)
    aasmonth.innerHTML = '<option value="0">--SELECT AAS MONTH--</option>';
    MONTHS_33.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m.id;
      opt.dataset.month = m.ym;
      opt.textContent = `${m.name} (${m.days} days)`;
      aasmonth.appendChild(opt);
    });

    // Populate Surrender Leave Month Selects by Year
    surrenderYears.forEach(sy => {
      if (sy.monthSelect) {
        sy.monthSelect.innerHTML = `<option value="0">--${sy.year} సరెండర్ నెల ఎంచుకోండి--</option>`;
        const yearMonths = MONTHS_33.filter(m => m.year === sy.year);
        yearMonths.forEach(m => {
          const opt = document.createElement('option');
          opt.value = m.id;
          opt.textContent = `${m.name}`;
          sy.monthSelect.appendChild(opt);
        });
      }
    });

    // Populate Cumulative DA Table
    if (tsCumulativeTableBody && typeof TS_CUMULATIVE_DA_TABLE !== 'undefined') {
      tsCumulativeTableBody.innerHTML = '';
      TS_CUMULATIVE_DA_TABLE.forEach(row => {
        const tr = document.createElement('tr');
        if (row.isNew) {
          tr.style.background = '#ecfdf5';
          tr.style.fontWeight = 'bold';
        } else if (row.isLastDrawn) {
          tr.style.background = '#fef3c7';
          tr.style.fontWeight = 'bold';
        }
        tr.innerHTML = `
          <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; font-weight: 700;">${row.period} ${row.daCount ? `<span style="font-size:0.7rem; background:#059669; color:#fff; padding:2px 6px; border-radius:4px; margin-left:4px;">${row.daCount}</span>` : ''}</td>
          <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; text-align: right;">+${row.incr.toFixed(2)}%</td>
          <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; text-align: right; color: #047857; font-weight: 800;">${row.cumulative.toFixed(2)}%</td>
          <td style="padding: 7px 10px; border-bottom: 1px solid #e2e8f0; font-size: 0.76rem; color: #475569;">${row.remarks}</td>
        `;
        tsCumulativeTableBody.appendChild(tr);
      });
    }
  }

  // --- 2. AAS Dynamic Days Generation ---
  function updateAasDays() {
    const selectedMonthId = parseInt(aasmonth.value, 10);
    if (selectedMonthId >= 1 && selectedMonthId <= 33) {
      const monthObj = MONTHS_33[selectedMonthId - 1];
      const daysCount = monthObj.days;
      aasday.innerHTML = '<option value="1">1st of Month (Full Month - మొత్తం నెల)</option>';
      for (let d = 2; d <= daysCount; d++) {
        const opt = document.createElement('option');
        opt.value = d;
        opt.textContent = `${d}th of ${monthObj.name} (Pro-rata దామాషా)`;
        aasday.appendChild(opt);
      }
      aasDayDiv.style.display = 'block';
    } else {
      aasday.innerHTML = '<option value="1">1st of Month</option>';
      aasDayDiv.style.display = 'none';
    }
  }

  // --- 3. Year-by-Year Surrender Leave Dynamic Handlers ---
  function initSurrenderLeaveHandlers() {
    function updateProgressiveYears() {
      const sy2024 = surrenderYears[0];
      const sy2025 = surrenderYears[1];
      const sy2026 = surrenderYears[2];

      const val2024 = sy2024.slSelect.value;
      const m2024 = sy2024.monthSelect.value;
      const is2024Answered = (val2024 === '1') || ((val2024 === '2' || val2024 === '3') && m2024 !== '0');

      if (is2024Answered) {
        sy2025.item.style.display = 'block';
        sy2025.chip.classList.add('year-chip--active');
        sy2024.chip.classList.add('year-chip--completed');
      } else {
        if (val2024 !== '1' && m2024 === '0' && sy2025.slSelect.value === '1' && sy2026.slSelect.value === '1') {
          sy2025.item.style.display = 'none';
          sy2025.chip.classList.remove('year-chip--active', 'year-chip--completed');
          sy2026.item.style.display = 'none';
          sy2026.chip.classList.remove('year-chip--active', 'year-chip--completed');
        }
      }

      const val2025 = sy2025.slSelect.value;
      const m2025 = sy2025.monthSelect.value;
      const is2025Answered = (val2025 === '1') || ((val2025 === '2' || val2025 === '3') && m2025 !== '0');

      if (is2024Answered && is2025Answered) {
        sy2026.item.style.display = 'block';
        sy2026.chip.classList.add('year-chip--active');
        sy2025.chip.classList.add('year-chip--completed');
      } else {
        if (val2025 !== '1' && m2025 === '0' && sy2026.slSelect.value === '1') {
          sy2026.item.style.display = 'none';
          sy2026.chip.classList.remove('year-chip--active', 'year-chip--completed');
        }
      }

      const val2026 = sy2026.slSelect.value;
      const m2026 = sy2026.monthSelect.value;
      if ((val2026 === '1') || ((val2026 === '2' || val2026 === '3') && m2026 !== '0')) {
        sy2026.chip.classList.add('year-chip--completed');
      }
    }

    surrenderYears.forEach(sy => {
      if (!sy.slSelect) return;

      sy.slSelect.addEventListener('change', () => {
        const val = sy.slSelect.value;
        if (val === '2' || val === '3') {
          sy.monthDiv.style.display = 'block';
        } else {
          sy.monthDiv.style.display = 'none';
          sy.monthSelect.value = '0';
        }
        updateProgressiveYears();
        calculateAndRender();
      });

      if (sy.monthSelect) {
        sy.monthSelect.addEventListener('change', () => {
          updateProgressiveYears();
          calculateAndRender();
        });
      }
    });
  }

  // --- 4. Search Filter for Basic Pay Select ---
  function initSearchFilter() {
    basicSearch.addEventListener('input', () => {
      const q = basicSearch.value.trim().toLowerCase();
      let firstMatch = null;
      Array.from(basicpay.options).forEach(opt => {
        const match = opt.textContent.toLowerCase().includes(q) || opt.value.includes(q);
        opt.style.display = match ? '' : 'none';
        if (match && !firstMatch) firstMatch = opt;
      });
      if (firstMatch && q.length >= 2 && firstMatch.value !== '') {
        basicpay.value = firstMatch.value;
        calculateAndRender();
      }
    });

    customPayCheck.addEventListener('change', () => {
      if (customPayCheck.checked) {
        customPayWrapper.style.display = 'block';
        customPayInput.focus();
      } else {
        customPayWrapper.style.display = 'none';
      }
      calculateAndRender();
    });

    customPayInput.addEventListener('input', calculateAndRender);
  }

  // --- 5. Main Calculation Engine ---
  function calculateAndRender() {
    const resultsContainer = document.getElementById('results');

    // 5.1 Determine Active Basic Pay as on 30 Sep 2026
    let activeBasic = 0;
    if (customPayCheck && customPayCheck.checked && customPayInput.value) {
      const customVal = parseInt(customPayInput.value, 10);
      if (customVal && customVal > 0) activeBasic = customVal;
    } else if (basicpay && basicpay.value) {
      activeBasic = parseInt(basicpay.value, 10) || 0;
    }

    if (!activeBasic || activeBasic <= 0) {
      if (activeBasicDisplay) activeBasicDisplay.textContent = '—';
      if (resultsContainer) resultsContainer.style.display = 'none';
      if (topOctTotal) topOctTotal.textContent = '—';
      if (topOctCash) topOctCash.textContent = '—';
      if (topOctCps) topOctCps.textContent = '—';
      return;
    }

    if (activeBasicDisplay) {
      activeBasicDisplay.textContent = `₹${formatINR(activeBasic)}`;
    }
    if (resultsContainer) {
      resultsContainer.style.display = 'block';
    }

    // 5.2 Pension Type: CPS (1) or GPF (2)
    const isCPS = (cpsorgpf.value === '1');

    // 5.3 Increment progression (Months 1 to 33)
    const incVal = parseInt(incmonth.value, 10); // 0 or 22..33
    const monthBasics = new Array(34).fill(activeBasic); // 1-indexed (1 to 33)

    if (incVal >= 22 && incVal <= 33) {
      const targetM = incVal; // e.g. 31 for July 2026, 22 for Oct 2025
      const prev1 = getPreviousPayStage(activeBasic);
      const prev2 = getPreviousPayStage(prev1);

      for (let m = 1; m <= 33; m++) {
        if (m >= targetM) {
          monthBasics[m] = activeBasic;
        } else if (m >= (targetM - 12)) {
          monthBasics[m] = prev1;
        } else {
          monthBasics[m] = prev2;
        }
      }
    }

    // 5.4 AAS Effect (if taken)
    const hasAas = (aas.value === '2');
    const aasM = parseInt(aasmonth.value, 10) || 0;
    const aasD = parseInt(aasday.value, 10) || 1;

    if (hasAas && aasM >= 1 && aasM <= 33) {
      // AAS gives 1 additional stage upgrade starting from aasM & aasD
      // That means prior to aasM, the employee was 1 stage lower than normal
      for (let m = 1; m <= 33; m++) {
        if (m < aasM) {
          monthBasics[m] = getPreviousPayStage(monthBasics[m]);
        } else if (m === aasM) {
          if (aasD > 1) {
            const daysInM = MONTHS_33[m - 1].days;
            const oldStage = getPreviousPayStage(monthBasics[m]);
            const newStage = monthBasics[m];
            const oldDays = aasD - 1;
            const newDays = daysInM - oldDays;
            monthBasics[m] = Math.round((oldStage * oldDays + newStage * newDays) / daysInM);
          }
        }
      }
    }

    // 5.5 Calculate DA Rate 1 Table (Jan-2024 to Sep-2026 = 33 Months)
    let da1TotBasic = 0;
    let da1TotEligible = 0;
    let da1TotDrawn = 0;
    let da1TotDiff = 0;
    let da1TotCps = 0;
    let da1TotCash = 0;

    let da1RowsHtml = '';

    for (let i = 0; i < 33; i++) {
      const mObj = MONTHS_33[i];
      const mIdx = i + 1;
      const bp = monthBasics[mIdx];
      const eligible = Math.round(bp * DA_RATES.DA_1_RATE);
      const drawn = Math.round(bp * DA_RATES.DRAWN_DA_RATE);
      const diff = eligible - drawn;
      const cps = isCPS ? Math.round(diff * DA_RATES.CPS_RATE) : 0;
      const cash = isCPS ? (diff - cps) : diff;

      da1TotBasic += bp;
      da1TotEligible += eligible;
      da1TotDrawn += drawn;
      da1TotDiff += diff;
      da1TotCps += cps;
      da1TotCash += cash;

      da1RowsHtml += `
        <tr>
          <th>${mObj.name}</th>
          <td>${formatINR(bp)}</td>
          <td>${formatINR(eligible)}</td>
          <td>${formatINR(drawn)}</td>
          <td>${formatINR(diff)}</td>
          <td class="col-cps">${isCPS ? formatINR(cps) : '—'}</td>
          <td class="col-cash">${formatINR(cash)}</td>
        </tr>
      `;
    }

    da1RowsHtml += `
      <tr class="total-row">
        <th>TOTAL</th>
        <td>${formatINR(da1TotBasic)}</td>
        <td>${formatINR(da1TotEligible)}</td>
        <td>${formatINR(da1TotDrawn)}</td>
        <td>${formatINR(da1TotDiff)}</td>
        <td class="col-cps">${isCPS ? formatINR(da1TotCps) : '—'}</td>
        <td class="col-cash">${formatINR(da1TotCash)}</td>
      </tr>
    `;
    da1TableBody.innerHTML = da1RowsHtml;

    // 5.6 Calculate DA Rate 2 Table (Jul-2024 to Sep-2026 = 27 Months)
    let da2TotBasic = 0;
    let da2TotEligible = 0;
    let da2TotDrawn = 0;
    let da2TotDiff = 0;
    let da2TotCps = 0;
    let da2TotCash = 0;

    let da2RowsHtml = '';

    for (let i = 6; i < 33; i++) {
      const mObj = MONTHS_33[i];
      const mIdx = i + 1;
      const bp = monthBasics[mIdx];
      const eligible = Math.round(bp * DA_RATES.DA_2_RATE);
      const drawn = Math.round(bp * DA_RATES.DA_1_RATE);
      const diff = eligible - drawn;
      const cps = isCPS ? Math.round(diff * DA_RATES.CPS_RATE) : 0;
      const cash = isCPS ? (diff - cps) : diff;

      da2TotBasic += bp;
      da2TotEligible += eligible;
      da2TotDrawn += drawn;
      da2TotDiff += diff;
      da2TotCps += cps;
      da2TotCash += cash;

      da2RowsHtml += `
        <tr>
          <th>${mObj.name}</th>
          <td>${formatINR(bp)}</td>
          <td>${formatINR(eligible)}</td>
          <td>${formatINR(drawn)}</td>
          <td>${formatINR(diff)}</td>
          <td class="col-cps">${isCPS ? formatINR(cps) : '—'}</td>
          <td class="col-cash">${formatINR(cash)}</td>
        </tr>
      `;
    }

    da2RowsHtml += `
      <tr class="total-row">
        <th>TOTAL</th>
        <td>${formatINR(da2TotBasic)}</td>
        <td>${formatINR(da2TotEligible)}</td>
        <td>${formatINR(da2TotDrawn)}</td>
        <td>${formatINR(da2TotDiff)}</td>
        <td class="col-cps">${isCPS ? formatINR(da2TotCps) : '—'}</td>
        <td class="col-cash">${formatINR(da2TotCash)}</td>
      </tr>
    `;
    da2TableBody.innerHTML = da2RowsHtml;

    // 5.7 Surrender Leave Calculation
    let totalSlAmount = 0;
    const slChipsData = [];

    surrenderYears.forEach(sl => {
      if (!sl.slSelect) return;
      const slType = sl.slSelect.value; // '1'=None, '2'=15d, '3'=30d
      const slM = parseInt(sl.monthSelect ? sl.monthSelect.value : '0', 10);

      if ((slType === '2' || slType === '3') && slM >= 1 && slM <= 33) {
        const mObj = MONTHS_33[slM - 1];
        const bp = monthBasics[slM];
        const full30 = Math.round(bp * DA_RATES.SL_RATE);
        const amount = (slType === '2') ? Math.round(full30 / 2) : full30;
        totalSlAmount += amount;
        slChipsData.push({
          monthName: mObj.name,
          days: slType === '2' ? 15 : 30,
          amount: amount
        });
      }
    });

    // 5.8 Grand Total
    const grandDiff = da1TotDiff + da2TotDiff + totalSlAmount;
    const grandCps = da1TotCps + da2TotCps; // SL has no CPS deduction
    const grandCash = isCPS ? (grandDiff - grandCps) : grandDiff;

    gtDiff.textContent = `₹${formatINR(grandDiff)}`;
    gtCps.textContent = isCPS ? `₹${formatINR(grandCps)}` : '—';
    gtCash.textContent = `₹${formatINR(grandCash)}`;

    if (totalSlAmount > 0) {
      const slDesc = slChipsData.map(c => `For ${c.monthName} (${c.days} Days): ₹${formatINR(c.amount)}`).join(' | ');
      gtSurrenderRow.innerHTML = `<td colspan="7" style="color: #92400e; font-weight: 700; background: #fef3c7;">🏖️ Surrender Leave Arrears Total: <strong>₹${formatINR(totalSlAmount)}</strong> <br><span style="font-size:0.80rem; font-weight:normal;">(${slDesc})</span></td>`;
    } else {
      gtSurrenderRow.innerHTML = `<td colspan="7">Surrender Leave Not Taken</td>`;
    }

    // 5.9 Update Summary Cards
    cardTotalArrears.textContent = `₹${formatINR(grandDiff)}`;
    if (isCPS) {
      cardCpsWrapper.style.display = 'flex';
      cardCpsLabel.textContent = 'CPS Account (10%)';
      cardCpsVal.textContent = `₹${formatINR(grandCps)}`;
      cardCashLabel.textContent = 'CPS Net Cash (90%)';
      cardCashVal.textContent = `₹${formatINR(grandCash)}`;
    } else {
      cardCpsWrapper.style.display = 'none';
      cardCashLabel.textContent = 'Total Net Cash (100% GPF)';
      cardCashVal.textContent = `₹${formatINR(grandCash)}`;
    }

    // Monthly Installments (33 installments for DA 1, 27 installments for DA 2)
    const da1InstDiff = Math.round(da1TotDiff / 33);
    const da1InstCps = isCPS ? Math.round(da1TotCps / 33) : 0;
    const da1InstCash = isCPS ? (da1InstDiff - da1InstCps) : da1InstDiff;

    const da2InstDiff = Math.round(da2TotDiff / 27);
    const da2InstCps = isCPS ? Math.round(da2TotCps / 27) : 0;
    const da2InstCash = isCPS ? (da2InstDiff - da2InstCps) : da2InstDiff;

    const combinedInstDiff = da1InstDiff + da2InstDiff;
    const combinedInstCash = da1InstCash + da2InstCash;
    const combinedInstCps = da1InstCps + da2InstCps;

    if (isCPS) {
      cardInstallSplit.innerHTML = `
        <div class="install-split-grid">
          <!-- 1st DA (1/33 Installment) -->
          <div class="install-row-item">
            <div class="install-row-header">
              <span class="install-tag tag-da1">1st DA (1/33 వాయిదా)</span>
              <span class="install-period">33 నెలలు (33 Installments)</span>
            </div>
            <div class="install-row-values">
              <span class="inst-val-box">
                <span class="inst-val-lbl">Cash:</span>
                <strong class="inst-cash">₹${formatINR(da1InstCash)}</strong>
              </span>
              <span class="inst-math-sign">+</span>
              <span class="inst-val-box">
                <span class="inst-val-lbl">CPS:</span>
                <strong class="inst-cps">₹${formatINR(da1InstCps)}</strong>
              </span>
              <span class="inst-math-sign">=</span>
              <span class="inst-val-box inst-val-box--total">
                <span class="inst-val-lbl">నెలకు మొత్తం (1/33):</span>
                <strong class="inst-tot">₹${formatINR(da1InstDiff)}</strong>
              </span>
            </div>
          </div>

          <!-- 2nd DA (1/27 Installment) -->
          <div class="install-row-item">
            <div class="install-row-header">
              <span class="install-tag tag-da2">2nd DA (1/27 వాయిదా)</span>
              <span class="install-period">27 నెలలు (27 Installments)</span>
            </div>
            <div class="install-row-values">
              <span class="inst-val-box">
                <span class="inst-val-lbl">Cash:</span>
                <strong class="inst-cash">₹${formatINR(da2InstCash)}</strong>
              </span>
              <span class="inst-math-sign">+</span>
              <span class="inst-val-box">
                <span class="inst-val-lbl">CPS:</span>
                <strong class="inst-cps">₹${formatINR(da2InstCps)}</strong>
              </span>
              <span class="inst-math-sign">=</span>
              <span class="inst-val-box inst-val-box--total">
                <span class="inst-val-lbl">నెలకు మొత్తం (1/27):</span>
                <strong class="inst-tot">₹${formatINR(da2InstDiff)}</strong>
              </span>
            </div>
          </div>
        </div>
      `;
    } else {
      cardInstallSplit.innerHTML = `
        <div class="install-split-grid">
          <!-- 1st DA (1/33 Installment) -->
          <div class="install-row-item">
            <div class="install-row-header">
              <span class="install-tag tag-da1">1st DA (1/33 వాయిదా)</span>
              <span class="install-period">33 నెలలు (GPF 100%)</span>
            </div>
            <div class="install-row-values">
              <span class="inst-val-box inst-val-box--total">
                <span class="inst-val-lbl">నెలకు 1/33 వాయిదా (GPF జమా):</span>
                <strong class="inst-tot">₹${formatINR(da1InstDiff)}</strong>
              </span>
            </div>
          </div>

          <!-- 2nd DA (1/27 Installment) -->
          <div class="install-row-item">
            <div class="install-row-header">
              <span class="install-tag tag-da2">2nd DA (1/27 వాయిదా)</span>
              <span class="install-period">27 నెలలు (GPF 100%)</span>
            </div>
            <div class="install-row-values">
              <span class="inst-val-box inst-val-box--total">
                <span class="inst-val-lbl">నెలకు 1/27 వాయిదా (GPF జమా):</span>
                <strong class="inst-tot">₹${formatINR(da2InstDiff)}</strong>
              </span>
            </div>
          </div>
        </div>
      `;
    }

    // Surrender Leave Card
    if (totalSlAmount > 0) {
      cardSlWrapper.style.display = 'flex';
      cardSlTotal.textContent = `₹${formatINR(totalSlAmount)}`;
      cardSlChips.innerHTML = slChipsData.map(c => `
        <span class="meta-chip">${c.monthName}: ₹${formatINR(c.amount)} (${c.days}d)</span>
      `).join('');
    } else {
      cardSlWrapper.style.display = 'none';
    }

    // 5.10 October 2026 Salary Banner / Card (Payable in Nov 2026)
    const bpOct = monthBasics[33]; // Sep 2026 basic pay applies for Oct 2026
    const octDiff1 = Math.round(bpOct * DA_RATES.DA_1_RATE) - Math.round(bpOct * DA_RATES.DRAWN_DA_RATE);
    const octDiff2 = Math.round(bpOct * DA_RATES.DA_2_RATE) - Math.round(bpOct * DA_RATES.DA_1_RATE);

    const octCps1 = isCPS ? Math.round(octDiff1 * DA_RATES.CPS_RATE) : 0;
    const octCash1 = isCPS ? (octDiff1 - octCps1) : octDiff1;

    const octCps2 = isCPS ? Math.round(octDiff2 * DA_RATES.CPS_RATE) : 0;
    const octCash2 = isCPS ? (octDiff2 - octCps2) : octDiff2;

    const octTotalCash = octCash1 + octCash2;
    const octTotalCps = octCps1 + octCps2;

    octBigCash.textContent = `₹${formatINR(octTotalCash)}`;
    octBadgeCash.textContent = isCPS ? 'CASH IN HAND (90%)' : 'CASH IN SALARY (100%)';

    if (isCPS) {
      octCpsPill.style.display = 'flex';
      octCpsVal.textContent = `₹${formatINR(octTotalCps)}`;
    } else {
      octCpsPill.style.display = 'none';
    }

    octDa1Cash.textContent = `Cash: ₹${formatINR(octCash1)}`;
    octDa1Cps.textContent = isCPS ? `CPS: ₹${formatINR(octCps1)}` : 'GPF 100%';

    octDa2Cash.textContent = `Cash: ₹${formatINR(octCash2)}`;
    octDa2Cps.textContent = isCPS ? `CPS: ₹${formatINR(octCps2)}` : 'GPF 100%';

    // Update Top October 2026 Highlight Card (beside Author Photo)
    if (topOctTotal) topOctTotal.textContent = `₹${formatINR(octDiff1 + octDiff2)}`;
    if (topOctCash) topOctCash.textContent = `₹${formatINR(octTotalCash)}`;
    if (topOctCps) topOctCps.textContent = `₹${formatINR(octTotalCps)}`;
    if (topOctCpsChip) {
      topOctCpsChip.style.display = isCPS ? 'inline-flex' : 'none';
    }

    // 5.11 Combined Installment Payment Table (if present in DOM)
    if (installmentTableBody && installmentMobileContainer) {
      const installMonths = [
        'Oct 2026', 'Nov 2026', 'Dec 2026',
        'Jan 2027', 'Feb 2027', 'Mar 2027', 'Apr 2027', 'May 2027', 'Jun 2027', 'Jul 2027', 'Aug 2027', 'Sep 2027', 'Oct 2027', 'Nov 2027', 'Dec 2027',
        'Jan 2028', 'Feb 2028', 'Mar 2028', 'Apr 2028', 'May 2028', 'Jun 2028', 'Jul 2028', 'Aug 2028', 'Sep 2028', 'Oct 2028', 'Nov 2028', 'Dec 2028',
        'Jan 2029', 'Feb 2029', 'Mar 2029', 'Apr 2029', 'May 2029', 'Jun 2029'
      ];

      let instRowsHtml = `
        <tr class="row-installment-total">
          <th colspan="2">Total</th>
          <td>₹${formatINR(da1TotCash)}</td>
          <td>${isCPS ? '₹' + formatINR(da1TotCps) : '—'}</td>
          <td>₹${formatINR(da2TotCash)}</td>
          <td>${isCPS ? '₹' + formatINR(da2TotCps) : '—'}</td>
          <td>₹${formatINR(da1TotCash + da2TotCash)}</td>
          <td>${isCPS ? '₹' + formatINR(da1TotCps + da2TotCps) : '—'}</td>
        </tr>
      `;

      let mobileCardsHtml = '';

      for (let idx = 0; idx < 33; idx++) {
        const slNo = idx + 1;
        const mName = installMonths[idx];
        const hasDa2 = (slNo <= 27);

        const d1Cash = da1InstCash;
        const d1Cps = isCPS ? da1InstCps : 0;

        const d2Cash = hasDa2 ? da2InstCash : 0;
        const d2Cps = (hasDa2 && isCPS) ? da2InstCps : 0;

        const totCash = d1Cash + d2Cash;
        const totCps = d1Cps + d2Cps;

        instRowsHtml += `
          <tr>
            <td><span class="inst-pill">#${slNo}</span></td>
            <td><strong>${mName}</strong></td>
            <td><span class="val-cash">₹${formatINR(d1Cash)}</span></td>
            <td><span class="val-cps">${isCPS ? '₹' + formatINR(d1Cps) : '—'}</span></td>
            <td><span class="val-cash">${hasDa2 ? '₹' + formatINR(d2Cash) : '—'}</span></td>
            <td><span class="val-cps">${(hasDa2 && isCPS) ? '₹' + formatINR(d2Cps) : '—'}</span></td>
            <td><span class="val-cash">₹${formatINR(totCash)}</span></td>
            <td><span class="val-cps">${isCPS ? '₹' + formatINR(totCps) : '—'}</span></td>
          </tr>
        `;

        mobileCardsHtml += `
          <article class="install-mobile-card">
            <header class="install-mobile-head">
              <span class="install-badge">#${slNo}</span>
              <span class="install-month-title">${mName}</span>
              <span style="font-size:0.72rem; color:#fde047; font-weight:800;">${hasDa2 ? 'DA 1 + DA 2' : 'DA 1 Only'}</span>
            </header>
            <div class="install-mobile-body">
              <div class="install-mobile-line">
                <span class="line-label">DA 1 (37.31%)</span>
                <div>
                  <span class="val-cash">Cash ₹${formatINR(d1Cash)}</span>
                  ${isCPS ? `<span class="val-cps" style="margin-left:6px;">CPS ₹${formatINR(d1Cps)}</span>` : ''}
                </div>
              </div>
              ${hasDa2 ? `
              <div class="install-mobile-line">
                <span class="line-label">DA 2 (40.04%)</span>
                <div>
                  <span class="val-cash">Cash ₹${formatINR(d2Cash)}</span>
                  ${isCPS ? `<span class="val-cps" style="margin-left:6px;">CPS ₹${formatINR(d2Cps)}</span>` : ''}
                </div>
              </div>` : ''}
              <div class="install-mobile-line install-mobile-line--sum">
                <span class="line-label">Month Total</span>
                <div>
                  <span class="val-cash" style="font-size:1rem;">Cash ₹${formatINR(totCash)}</span>
                  ${isCPS ? `<span class="val-cps" style="margin-left:6px;">CPS ₹${formatINR(totCps)}</span>` : ''}
                </div>
              </div>
            </div>
          </article>
        `;
      }

      installmentTableBody.innerHTML = instRowsHtml;
      installmentMobileContainer.innerHTML = mobileCardsHtml;
    }

    // Show/hide CPS columns if GPF
    document.querySelectorAll('.col-cps').forEach(el => {
      el.style.display = isCPS ? '' : 'none';
    });
  }

  // --- 6. Event Listeners ---
  // Form input changes trigger instant recalculation
  basicpay.addEventListener('change', () => {
    calculateAndRender();
    // When Basic Pay is selected, automatically scroll to Increment Month
    if (basicpay.value && basicpay.value !== '') {
      const incEl = document.getElementById('incMonthGroup') || document.getElementById('incmonth');
      if (incEl) {
        setTimeout(() => {
          incEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
          if (incmonth) {
            incmonth.focus({ preventScroll: true });
          }
        }, 150);
      }
    }
  });
  incmonth.addEventListener('change', calculateAndRender);
  cpsorgpf.addEventListener('change', calculateAndRender);

  aas.addEventListener('change', () => {
    if (aas.value === '2') {
      aasMonthDiv.style.display = 'block';
    } else {
      aasMonthDiv.style.display = 'none';
      aasDayDiv.style.display = 'none';
      aasmonth.value = '0';
      aasday.value = '1';
    }
    calculateAndRender();
  });

  aasmonth.addEventListener('change', () => {
    updateAasDays();
    calculateAndRender();
  });

  aasday.addEventListener('change', calculateAndRender);

  // Calculate Button click scrolls to results
  btnCalculate.addEventListener('click', () => {
    const isCustom = customPayCheck && customPayCheck.checked && customPayInput.value;
    const hasBasic = isCustom || (basicpay && basicpay.value && basicpay.value !== '');
    if (!hasBasic) {
      alert('దయచేసి ముందుగా మీ Basic Pay (Select Basic Pay As On 30-Sep-2026) ఎంచుకోండి!');
      basicpay.focus();
      basicpay.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    calculateAndRender();
    const resEl = document.getElementById('results');
    if (resEl) {
      resEl.style.display = 'block';
      resEl.scrollIntoView({ behavior: 'smooth' });
    }
  });

  const calcAuthorCompanion = document.getElementById('calcAuthorCompanion');
  if (calcAuthorCompanion) {
    calcAuthorCompanion.addEventListener('click', () => {
      btnCalculate.click();
    });
  }

  // Action: Print
  btnPrint.addEventListener('click', () => {
    window.print();
  });

  // Action: WhatsApp Share / Copy Summary
  btnShare.addEventListener('click', () => {
    const activeBp = customPayCheck.checked && customPayInput.value ? customPayInput.value : basicpay.value;
    const isCPS = (cpsorgpf.value === '1');
    const totArr = cardTotalArrears.textContent;
    const cashVal = cardCashVal.textContent;
    const cpsVal = cardCpsVal.textContent;
    const octVal = octBigCash.textContent;

    const summaryText = [
      `📊 *Telangana Govt 2 DAs Difference & Arrears Statement*`,
      `━━━━━━━━━━━━━━━━━━━━━━━━━━`,
      `🔹 మూల వేతనం (Basic Pay As On Sep-2026): ₹${formatINR(activeBp)}`,
      `🔹 Scheme: ${isCPS ? 'CPS (10% PRAN Deduction)' : 'GPF (100% Cash/GPF)'}`,
      `💰 *Total DA Arrears:* ${totArr}`,
      isCPS ? `🏛️ *CPS Account (10%):* ${cpsVal}` : null,
      `💵 *${isCPS ? 'CPS Net Cash (90%)' : 'Net Cash'}:* ${cashVal}`,
      `🎉 *Oct-2026 Monthly Cash Hike:* ${octVal} / month`,
      `━━━━━━━━━━━━━━━━━━━━━━━━━━`,
      `✅ Sanctioned vide G.O.Ms.128 (37.31%) & G.O.Ms.130 (40.04%)`,
      `Prepared by: Nancharla Prudhvi, Senior Accountant, Khammam Treasury`
    ].filter(Boolean).join('\n');

    navigator.clipboard.writeText(summaryText).then(() => {
      const origText = btnShare.innerHTML;
      btnShare.innerHTML = '<span>✅</span><span>Copied to Clipboard!</span>';
      setTimeout(() => { btnShare.innerHTML = origText; }, 2500);
    }).catch(() => {
      alert(summaryText);
    });
  });

  // Action: Reset
  btnReset.addEventListener('click', () => {
    basicpay.value = '';
    basicSearch.value = '';
    customPayCheck.checked = false;
    customPayWrapper.style.display = 'none';
    customPayInput.value = '';
    incmonth.value = '0';
    aas.value = '1';
    aasMonthDiv.style.display = 'none';
    aasDayDiv.style.display = 'none';
    aasmonth.value = '0';
    aasday.value = '1';
    cpsorgpf.value = '1';

    surrenderYears.forEach((sy, idx) => {
      if (sy.slSelect) sy.slSelect.value = '1';
      if (sy.monthDiv) sy.monthDiv.style.display = 'none';
      if (sy.monthSelect) sy.monthSelect.value = '0';
      if (sy.item) sy.item.style.display = (idx === 0) ? 'block' : 'none';
      if (sy.chip) {
        sy.chip.classList.toggle('year-chip--active', idx === 0);
        sy.chip.classList.remove('year-chip--completed');
      }
    });

    calculateAndRender();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });

  // Accordion Toggle
  tsTableToggle.addEventListener('click', () => {
    const isHidden = (tsTableContent.style.display === 'none');
    tsTableContent.style.display = isHidden ? 'block' : 'none';
    tsTableArrow.textContent = isHidden ? '▲' : '▼';
  });

  // --- Initial Launch ---
  populateDropdowns();
  initSurrenderLeaveHandlers();
  initSearchFilter();
  calculateAndRender();

  // Mobile Auto-Scroll & Open Basic Pay on load
  const isMobile = window.innerWidth <= 768;
  setTimeout(() => {
    if (isMobile && basicpay) {
      basicpay.scrollIntoView({ behavior: 'smooth', block: 'center' });
      // Trigger focus and touch dropdown if supported
      basicpay.focus({ preventScroll: true });
    }
  }, 350);
});
