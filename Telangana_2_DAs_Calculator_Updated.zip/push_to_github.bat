@echo off
title Push to GitHub - Telangana 2 DAs Calculator
echo ========================================================
echo Telangana 2 DAs Calculator - GitHub Upload Helper
echo (1st DA @37.31%% w.e.f Jan 2024 ^& 2nd DA @40.04%% w.e.f Jul 2024)
echo ========================================================
echo.
echo Repo: https://github.com/PrudhviNancharla/Telangana-State-DA-calculator
echo.
echo Tip: If you don't have a token, you can easily drag and drop
echo the files directly in your browser at:
echo https://github.com/PrudhviNancharla/Telangana-State-DA-calculator/upload/main
echo.
set /p TOKEN="Enter your GitHub Personal Access Token (PAT): "
if "%TOKEN%"=="" (
    echo No token entered. Exiting...
    pause
    exit /b
)
cd /d "C:\Users\Admin\.gemini\antigravity\scratch\Telangana-State-DA-calculator"
"C:\Users\Admin\.gemini\antigravity\scratch\mingit\cmd\git.exe" add .
"C:\Users\Admin\.gemini\antigravity\scratch\mingit\cmd\git.exe" commit -m "Update DA calculator for 2 DAs: 1st DA @37.31% w.e.f Jan 24 and 2nd DA @40.04% w.e.f Jul 24"
"C:\Users\Admin\.gemini\antigravity\scratch\mingit\cmd\git.exe" branch -M main
"C:\Users\Admin\.gemini\antigravity\scratch\mingit\cmd\git.exe" push https://%TOKEN%@github.com/PrudhviNancharla/Telangana-State-DA-calculator.git main --force
echo.
echo ========================================================
echo Completed! Website repo updated successfully!
echo ========================================================
pause
